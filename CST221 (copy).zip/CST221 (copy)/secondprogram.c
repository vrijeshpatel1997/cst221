#include <stdio.h>
int main()
{
    int usernum;
    printf("Enter an integer: ");
    scanf("%d", &usernum);  
    if(usernum > 100)
    printf("user entered number that is higher than 100");
    else (usernum < 100);
     printf("user entered number that is lower than 100");
    
    printf(" The user number is  = %d",usernum);
    return 0;
}	
