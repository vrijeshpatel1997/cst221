#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>




void childProcess(){

for( int x=0; x<10; ++x){

printf(" child process : %d\n", x);
sleep(1);


}
	_exit(0);


}


void parentProcess(){
	
	for(int x=0; x< 10; ++x)
{


printf(" parent process : %d\n", x);
sleep(2);

}
	_exit(0);


}

int main (int argc, char* argv[])

{

// pid is created by someone
	pid_t pid;

// print pid
	printf("I am  process no: %d\n", (int)getpid());  // getpid method is prebuild in library 


	pid = fork();
	printf(" fork returned : %d\n", (int)pid);

if(pid == -1)
{

// fprintf types to files that error has occured
	fprintf(stderr, "cant fork, error %d\n", errno);
	exit(EXIT_FAILURE);

}

 else if(pid == 0)
{

	childProcess();

}

else {

// run the parent process logic

	parentProcess();


}
return 0;



}


