#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>


int main (int argc, char* argv[])

{

// pid is created by someone
pid_t pid;

// print pid
printf("I am  process no: %d\n", (int)getpid());  // getpid method is prebuild in library 


pid = fork();
printf(" fork returned : %d\n", (int)pid);

if(pid == -1)
{

// fprintf types to files that error has occured
fprintf(stderr, "cant fork, error %d\n", errno);
exit(EXIT_FAILURE);

}

 else if(pid == 0)
{

// child process logic  
printf(" I am the child with pid %d\n", (int)getpid());
sleep(10);
printf("child exiting...\n");
exit(0);

}

else {

// run the parent process logic

printf("i am parent with pid %d\n" , (int) getpid());

printf("waiting for child....\n");
wait(NULL);
printf(" parent is exiting \n");



}
return 0;
}
