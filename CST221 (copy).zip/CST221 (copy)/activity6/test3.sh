echo "Declaring variables"
name='Vrijesh'
age=23
echo "My name is" $name "and my age is " $age
