// Vrijesh patel
// cst 221
// 5/30/21
//This is my own work

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int i, j, x, final;
unsigned int decimal = -1, transform;
char binary_array [32];



void* displayBinary (){

	if (decimal >= 0 && decimal < 4096){
		unsigned int mask = 1<<31;

		for (i = 0; i < 8; i++){
			for (j = 0; j < 4; j++){
				char c = (decimal & mask) == 0 ? '0' : '1';
				binary_array[x++] = c;
				putchar(c);
				mask >>= 1;
			}
			putchar(' ');
		}
		putchar('\n');
	}
}

void* displayHex (){

	printf("%04x\n", decimal);
}

void* calcDecimal (){
	printf("%s", "The number in binary: ");
	displayBinary();
	printf("%s", "The number in hexadecimal: ");
	displayHex();
}

void* numberTransform (){

	transform = decimal << 16;

	final = transform & decimal;
	unsigned int addition = 0x07FF;
	final = final | addition;
	printf("New number in decimal: %d\n", final);
	decimal = final;
	calcDecimal();
}

int main (void){

	printf("%s", "Please enter a number between 0 and 4095: ");
	scanf("%d", &decimal);

	if (decimal < 0 || decimal > 4095){
		printf("%s", "Only a number within range is accepted.\n");
	}
	else {

		calcDecimal();
		numberTransform();
		return 0;
	}
}
