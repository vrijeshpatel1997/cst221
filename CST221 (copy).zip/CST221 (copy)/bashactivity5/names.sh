#!/bin/bash
for name in $( sort < names.txt )
do

    echo "Name is " $name
    if [ $name = "Vrijesh" ]
    then
      echo "I have found my self"

    fi
  done


  // take ss of txt.name and names.sh
