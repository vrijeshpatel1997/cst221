
#!/bin/bash

cowsay "I love you"
