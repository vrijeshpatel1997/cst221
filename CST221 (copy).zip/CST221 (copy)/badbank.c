#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define MAX_DEPOSITS 1000000

int balance = 0;

pthread_mutex_t  _mutex;



	void *deposit(void *a){


int x, tmp;

for(x = 0; x < MAX_DEPOSITS; ++x){


// start of   critical region
 pthread_mutex_lock(&_mutex);
tmp = balance;
tmp = tmp + 1;
balance = tmp;
// end of critcal region
pthread_mutex_unlock(&_mutex);

}
return NULL;
}

// LOGIN IN MAAIN BEFOR PTHREAD EXIT

int main ()
{


  pthread_mutex_init(&_mutex,0);



             if(balance < 2 * MAX_DEPOSITS)   {

              		printf("\n bad balance bank balance is  $%d and should be $%d\n", balance, 2 * MAX_DEPOSITS);


    }   else{



        printf("\n good balance bank balance is $%d\n", balance);


}

pthread_mutex_destroy(&_mutex);

return 0;
}

// gcc thread.c -lpthread
// ./a.out
