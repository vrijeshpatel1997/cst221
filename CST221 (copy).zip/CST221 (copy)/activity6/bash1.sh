echo "Current directory is"
pwd
