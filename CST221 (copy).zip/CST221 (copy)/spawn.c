#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <spawn.h>
#include <sys/wait.h>


extern char **environ; // external is library usoing it as a instance

void run_cmd(char *cmd){


		pid_t pid;
		char * argv[] = {"sh", "-c" , cmd, NULL};
		printf("Running command.....%s\n", cmd);
		status = posix_spawn(&pid, "bin/sh", NULL, NULL, argv, environ);
		

if( status == 0){

printf(" child process id (PID) is %i\n", pid);
if( waitpid(pid, &status, 0) != 1)

{

printf(" child process exited with status of %i\n", status);

}

}


} else{


printf(" failed to wait for child  ");



}
}
}


perror(" child process failed to spawn with error of '%s\n'", strerror(status));


int main(int argc, char*argv[])
{

// run a desired command by spawning off a child process specified by argv[1]

run_cmd(argv[1]);
return 0;

}
