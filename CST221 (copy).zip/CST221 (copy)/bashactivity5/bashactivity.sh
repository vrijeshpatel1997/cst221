#!/bin/bash
number=40

if [ $number -lt 50 ]
then
  echo "The number is less than 50"
elif [ $number -eq 50 ]
then
 echo "The number is 50"
else
  echo "The number is greater than 50"
fi

// 3 screenshort
