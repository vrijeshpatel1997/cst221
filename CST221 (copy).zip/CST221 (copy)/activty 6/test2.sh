echo "changing to my Home directory"
cd ~
echo "creating mycode directory"
mkdir mycode
cd mycode
