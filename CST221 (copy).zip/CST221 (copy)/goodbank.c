#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <semaphore.h>



sem_t* mutex;

int balance = 0;

sem_wait(mutex);


sem_post(mutex);



// LOGIN IN MAAIN BEFOR PTHREAD EXIT

int main ()
{

pthread_t tid1, tid2;


mutex = sem_open("Mutex", O_CREAT, 00644,1);
if(mutex == SEM_FAILED){

	printf("\n Error creating mutex" );
	exit(1);
}

// close named semaphore

sem_close(mutex);
pthread_exit(NULL);


}

// gcc thread.c -lpthread
// ./a.out
