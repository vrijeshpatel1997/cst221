#!/bin/bash
i=0
while [ $i -lt 10 ]
do
  echo The counter is $i
  i=$[$i+1]

done
