echo "Current directory is"
pwd
echo "changing to my home - directory"
cd ~
echo "changing to document directory"
cd Documents
echo "Documents  directory content is "
ls -all
echo "changing back to my home directory"
cd..
echp "current directory is"
pwd
