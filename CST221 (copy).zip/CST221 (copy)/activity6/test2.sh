echo "changing to my Home directory"
cd ~
echo "creating mycode directory"
mkdir mycode
cd mycode
echo "copying all C source code files to mycode directory..."
IFS=$'\n'
for file in $(find ~/Desktop/CST221 -name *.c)
do
cp $file .
done
echo "changing back to my home directory"
cd..
echo "creating mycode2 directory"
mkdir mycode2
echo "copying all C source code files to mycode2 directory"
cp mycode/* mycode2
echo "Renaming mycode directory to deadcode...."
mv mycode deadcode
echo "Deleting deadcode directory"
rm -R deadcode
