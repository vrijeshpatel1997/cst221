#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/mman.h>
#include <err.h>
// the child PID if


pid_t otherPid;

int WAKEUP = SIGUSR1;

sigset_t sigSet;


void sleepUntilWoken(){


  int nSig;
  printf("sleeping \n" );
  sigwait(&sigSet, &nSig);
  printf("awoken\n");
}

// consumer lofgic

sigemtyset(&sigSet);
sigaddset(&sigSet, WAKEUP);
sigprocmask(SIG_BLOCK, &sigSet, NUll);

//put the comsumer to sleep

printf("putting consumer to sleep forever\n" );
sleepUntilWoken();

// run the comsumer childProcess
int count = 0;

printf("Running consumer process ...\n" );
while(count < 20){


  printf(" consumer %d\n", count );
  sleep(1);

  ++count;

}

_exit(1);
/// This is the producer lofgic
 void Consumer(){


   int count = 0;

   printf("Ruuning producer process \n" );

   while(count < 30){

     printf("Producer %d\n", count);
     sleep(1);
     if(count == 5){

       printf("waking up the consumer \n" );
       kill(otherPid, WAKEUP);



     }

     ++count;

   }
   _exit(1);
 }



 void producer(){


   int count = 0;
   printf("Ruuning the process \n" );
 }
